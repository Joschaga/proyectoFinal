﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;

namespace ChanGymProyectoFinal
{
    public partial class datosClientes : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Bconsultar_Click(object sender, EventArgs e)
        {
            LlenarGridCliente();
        }
        protected void Bconsultar2_Click(object sender, EventArgs e)
        {
            LlenarGridFacturas();
        }
        protected void LlenarGridCliente()
        {
            string constr = ConfigurationManager.ConnectionStrings["ChanGymProyectoFinalConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Usuarios where Email = " + "'" + TRcorreo.Text + "'"))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.Connection = con;
                        sda.SelectCommand = cmd;
                        using (DataTable dt = new DataTable())
                        {
                            sda.Fill(dt);
                            GridView1.DataSource = dt;
                            GridView1.DataBind();
                        }
                    }
                }
            }
        }

        protected void LlenarGridFacturas()
        {
            
            string constr = ConfigurationManager.ConnectionStrings["ChanGymProyectoFinalConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand("select * from Factura where Cod_Usuario = " + int.Parse(TRcodusuario.Text)))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.Connection = con;
                        sda.SelectCommand = cmd;
                        using (DataTable dt = new DataTable())
                        {
                            sda.Fill(dt);
                            GridView2.DataSource = dt;
                            GridView2.DataBind();
                        }
                    }
                }
            }
        }

    }
}