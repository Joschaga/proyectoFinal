﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ChanGymProyectoFinal
{
    public partial class facturacion : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                DataTable dt = new DataTable();
                dt.Columns.AddRange(new DataColumn[5] { new DataColumn("Codigo"), new DataColumn("Nombre"), new DataColumn("Cantidad"), new DataColumn("Precio"), new DataColumn("Subtotal") });
                ViewState["Factura"] = dt;
                this.BindGrid();
            }
        }

        protected void BindGrid()
        {
            GridView1.DataSource = (DataTable)ViewState["Factura"];
            GridView1.DataBind();
        }

        protected void BFingresar_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable dt = (DataTable)ViewState["Factura"];
                int sb = (int.Parse(Tcantidad.Text) * int.Parse(Tprecio.Text));
                ViewState["Subtotal"] = (int.Parse(Tcantidad.Text) * int.Parse(Tprecio.Text));
                dt.Rows.Add(Tcodigo.Text.Trim(), Tproducto.Text.Trim(), Tcantidad.Text.Trim(), Tprecio.Text.Trim(), ViewState["Subtotal"]);
                ViewState["Factura"] = dt;
                this.BindGrid();

                //ViewState["Subtotal"] = (int.Parse(Lsubtotal.Text) + sb);
                Lsubtotal.Text = (ViewState["Subtotal"]).ToString();
                ViewState["IVA"] = (int.Parse(Lsubtotal.Text) * 0.13);
                Liva.Text = (ViewState["IVA"]).ToString();
                ViewState["Total"] = (int.Parse(Lsubtotal.Text) + int.Parse(Liva.Text));
                Ltotal.Text = (ViewState["Total"]).ToString();

                Tcodigo.Focus();
                Tcodigo.Text = "";
                Tproducto.Text = "";
                Tcantidad.Text = "";
                Tprecio.Text = "";
            }
            catch (Exception)
            { }
            finally
            { }
        }

        protected void BFfacturar_Click(object sender, EventArgs e)
        {
            Clsfactura.Codigo_Factura = 0;
            if (Clsfactura.AgregarMaestroFactura(Tproducto.Text, Ltotal.Text) > 0)
            {
                foreach (GridViewRow item in GridView1.Rows)
                {
                    int codigo = int.Parse(item.Cells[0].Text);
                    int cantidad = int.Parse(item.Cells[2].Text);
                    int precio = int.Parse(item.Cells[3].Text);

                    if (Clsfactura.AgregarDetalleFactura(Clsfactura.Codigo_Factura, codigo, cantidad, precio) > 0)
                    {
                        Clsfactura.Codigo_Factura++;
                    }
                }
                DataTable ds = new DataTable();
                ds = null;
                GridView1.DataSource = ds;
                GridView1.DataBind();
            }
        }

        protected void tcodigo_TextChanged(object sender, EventArgs e)
        {
            Tproducto.Text = Clsproducto.BuscarProducto(Tcodigo.Text);
            Tprecio.Text = Convert.ToString(Clsproducto.Precio);
            Tcantidad.Focus();
        }
    }
}