﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ChanGymProyectoFinal
{
    public partial class clientes : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            LlenarGridClientesTemp();
            LlenarGridClientes();
            LlenarGridProvincias();
            LlenarGridCantones();
            LlenarGridDistritos();
        }

        protected void BCingresar_Click(object sender, EventArgs e)
        {
            try
            {
                String s = System.Configuration.ConfigurationManager.ConnectionStrings["ChanGymProyectoFinalConnectionString"].ConnectionString;
                SqlConnection conexion = new SqlConnection(s);
                conexion.Open();
                SqlCommand comando = new SqlCommand("exec IngresarUsuarios " + "'" + TCnombre.Text + "', " + "'" + TCapellido.Text + "', "
                                                    + "'" + TCemail.Text + "', " + "'" + TCclave.Text + "', " + "'" + TCtelefono.Text + "', "
                                                    + "'" + DDLtipo.Text + "'", conexion);
                comando.ExecuteNonQuery();
                conexion.Close();
            }
            catch (Exception)
            { }
            LlenarGridClientesTemp();
        }

        protected void BCingresar2_Click(object sender, EventArgs e)
        {
            try
            {
                String s = System.Configuration.ConfigurationManager.ConnectionStrings["ChanGymProyectoFinalConnectionString"].ConnectionString;
                SqlConnection conexion = new SqlConnection(s);
                conexion.Open();
                SqlCommand comando = new SqlCommand("exec IngresarDirecciones " + int.Parse(TCcod_usuario.Text) + ", " + int.Parse(TCprovincia.Text) 
                                                    + ", " + int.Parse(TCcanton.Text) + ", " + int.Parse(TCdistrito.Text) + ", " + "'"
                                                    + TCdireccion.Text + "'", conexion);
                comando.ExecuteNonQuery();
                conexion.Close();
            }
            catch (Exception)
            { }
            LlenarGridClientes();
        }

        protected void BCmodificar_Click(object sender, EventArgs e)
        {
            try
            {
                String s = System.Configuration.ConfigurationManager.ConnectionStrings["ChanGymProyectoFinalConnectionString"].ConnectionString;
                SqlConnection conexion = new SqlConnection(s);
                conexion.Open();
                SqlCommand comando = new SqlCommand("exec ActualizarUsuarios " + int.Parse(TCcod_usuario.Text) + ", '" + TCnombre.Text + "', '"
                                                    + TCapellido.Text + "', '" + TCemail.Text + "', '" + TCclave.Text + "', '"
                                                    + TCtelefono.Text + "', '" + DDLtipo.Text + "'", conexion);
                SqlCommand comando2 = new SqlCommand("exec ActualizarDirecciones " + int.Parse(TCcod_usuario.Text) + ", " + int.Parse(TCcod_usuario.Text)
                                    + ", " + int.Parse(TCprovincia.Text) + ", " + int.Parse(TCcanton.Text) + ", "
                                    + int.Parse(TCdistrito.Text) + ", '" + TCdireccion.Text + "'", conexion);
                comando.ExecuteNonQuery();
                comando2.ExecuteNonQuery();
                conexion.Close();
            }
            catch (Exception)
            { }
            LlenarGridClientesTemp();
            LlenarGridClientes();
        }

        protected void BCborrar_Click(object sender, EventArgs e)
        {
            try
            {
                String s = System.Configuration.ConfigurationManager.ConnectionStrings["ChanGymProyectoFinalConnectionString"].ConnectionString;
                SqlConnection conexion = new SqlConnection(s);
                conexion.Open();
                SqlCommand comando = new SqlCommand("exec BorrarDirecciones " + int.Parse(TCcod_usuario.Text), conexion);
                SqlCommand comando2 = new SqlCommand("exec BorrarUsuarios " + int.Parse(TCcod_usuario.Text), conexion);
                comando.ExecuteNonQuery();
                comando2.ExecuteNonQuery();
                conexion.Close();
            }
            catch (Exception)
            { }
            LlenarGridClientesTemp();
            LlenarGridClientes();
        }

        protected void LlenarGridClientesTemp()
        {
            string constr = ConfigurationManager.ConnectionStrings["ChanGymProyectoFinalConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand("exec ConsultarUsuarios"))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.Connection = con;
                        sda.SelectCommand = cmd;
                        using (DataTable dt = new DataTable())
                        {
                            sda.Fill(dt);
                            GridView5.DataSource = dt;
                            GridView5.DataBind();
                        }
                    }
                }
            }
        }

        protected void LlenarGridClientes()
        {
            string constr = ConfigurationManager.ConnectionStrings["ChanGymProyectoFinalConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand("exec VerDatosUsuariosGym"))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.Connection = con;
                        sda.SelectCommand = cmd;
                        using (DataTable dt = new DataTable())
                        {
                            sda.Fill(dt);
                            GridView1.DataSource = dt;
                            GridView1.DataBind();
                        }
                    }
                }
            }
        }

        protected void LlenarGridProvincias()
        {
            string constr = ConfigurationManager.ConnectionStrings["ChanGymProyectoFinalConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand("exec ConsultarProvincia"))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.Connection = con;
                        sda.SelectCommand = cmd;
                        using (DataTable dt = new DataTable())
                        {
                            sda.Fill(dt);
                            GridView2.DataSource = dt;
                            GridView2.DataBind();
                        }
                    }
                }
            }
        }

        protected void LlenarGridCantones()
        {
            string constr = ConfigurationManager.ConnectionStrings["ChanGymProyectoFinalConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand("exec ConsultarCanton"))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.Connection = con;
                        sda.SelectCommand = cmd;
                        using (DataTable dt = new DataTable())
                        {
                            sda.Fill(dt);
                            GridView3.DataSource = dt;
                            GridView3.DataBind();
                        }
                    }
                }
            }
        }

        protected void LlenarGridDistritos()
        {
            string constr = ConfigurationManager.ConnectionStrings["ChanGymProyectoFinalConnectionString"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                using (SqlCommand cmd = new SqlCommand("exec ConsultarDistrito"))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter())
                    {
                        cmd.Connection = con;
                        sda.SelectCommand = cmd;
                        using (DataTable dt = new DataTable())
                        {
                            sda.Fill(dt);
                            GridView4.DataSource = dt;
                            GridView4.DataBind();
                        }
                    }
                }
            }
        }
    }
}