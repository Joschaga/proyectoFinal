﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Security.Claims;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ChanGymProyectoFinal
{
    public partial class index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Bingresar_Click(object sender, EventArgs e)
        {
            Clsusuarios.Email = Temail.Text;
            Clsusuarios.Clave = Tclave.Text;

            if (Clsusuarios.ValidarLogin(Clsusuarios.Email, Clsusuarios.Clave) > 0)
            {                
                if (Clsusuarios.Tipo.Equals("Admin"))
                {
                    Response.Redirect("inicioAdmin.aspx");
                }
                else
                {
                    Response.Redirect("inicioRegular.aspx");
                }
            }
            else
            {
                Lmensaje.Text = "Su Usuario o Contraseña son incorrectos";
            }
        }
    }
}