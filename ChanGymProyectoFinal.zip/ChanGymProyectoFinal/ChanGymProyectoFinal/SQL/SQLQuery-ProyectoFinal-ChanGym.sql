--SQL Queries para Proyecto Final Progra II / IIIQ Martes Noche
--Jos� Alfredo Chan Gamboa
--GIMNASIO

--Creamos la base de datos
create database ChanGymProyectoFinal
use ChanGymProyectoFinal

--Creamos las tablas
create table Usuarios
(
	Codigo_Usuarios int identity (1,1),
	Nombre nvarchar (50) not null,
	Apellido nvarchar (50) not null,
	Email nvarchar (50) not null,
	Clave nvarchar (50) not null,
	Telefono nvarchar (30) not null,
	Tipo nvarchar (30) not null,
	constraint pk_codUsu primary key(Codigo_Usuarios)
)

create table Producto
(
	Codigo_Producto int identity (1,1),
	Nombre nvarchar (50) not null,
	Precio int not null
	constraint pk_codProd primary key(Codigo_Producto)
)

create table Factura
(
	Num_Factura int not null,
	Fecha date constraint def_fecha default getdate(),
	Cod_Usuario int not null,
	Total int not null,
	IV_Total int not null,
	constraint pk_numFact primary key(Num_Factura),
	constraint fk_codUsuario foreign key(Cod_Usuario) references Usuarios(Codigo_Usuarios)
)

create table DetalleFactura
(
	Codigo_Factura int identity (1,1),
	N_Factura int not null,
	Codigo_Producto int not null,
	Cantidad int not null,
	Precio_Unitario int not null,
	IV int not null,
	constraint pk_codFact primary key(Codigo_Factura),
	constraint fk_numFactura foreign key(N_Factura) references Factura(Num_Factura)
)

create table Provincia
(
	Codigo_Provincia int,
	Nombre nvarchar (50) not null,
	constraint pk_codProv primary key(Codigo_Provincia)
)

create table Canton
(
	Codigo_Canton int,
	Nombre nvarchar (50) not null,
	Cod_Provincia int not null
	constraint pk_codCant primary key(Codigo_Canton)
	constraint fk_codProvi foreign key(Cod_Provincia) references Provincia(Codigo_Provincia)
)

create table Distrito
(
	Codigo_Distrito int,
	Nombre nvarchar (50) not null,
	Cod_Canton int not null
	constraint pk_codDist primary key(Codigo_Distrito)
	constraint fk_codCan foreign key(Cod_Canton) references Canton(Codigo_Canton)
)

create table Direcciones
(
	Codigo_Direcciones int identity (1,1),
	C_Usu int not null,
	C_Prov int not null,
	C_Cant int not null,
	C_Dist int not null,
	Comentarios nvarchar (50)
	constraint pk_codDir primary key(Codigo_Direcciones)
	constraint fk_cUsu foreign key(C_Usu) references Usuarios(Codigo_Usuarios),
	constraint fk_cProv foreign key(C_Prov) references Provincia(Codigo_Provincia),
	constraint fk_cCant foreign key(C_Cant) references Canton(Codigo_Canton),
	constraint fk_cDist foreign key(C_Dist) references Distrito(Codigo_Distrito)
)

--Creamos Store Procedures (SP)
--SP Tabla Ususarios
create procedure ConsultarUsuarios
	as
		begin
		select * from Usuarios
		end

create procedure IngresarUsuarios
	@Nombre nvarchar(50) = '',
	@Apellido nvarchar(50) = '',
	@Email nvarchar(50) = '',
	@Clave nvarchar(50) = '',
	@Telefono nvarchar(30) = '',	
	@Tipo varchar(30) = ''
	as
		begin
			insert into Usuarios (Nombre, Apellido, Email, Clave, Telefono, Tipo) values (@Nombre, @Apellido, @Email, @Clave, @Telefono, @Tipo)
		end

create procedure BorrarUsuarios
	@Codigo_Usuarios int
	as
		begin
			delete Usuarios where Codigo_Usuarios = @Codigo_Usuarios
		end

create procedure ActualizarUsuarios
	@Codigo_Usuarios int,
	@Nombre nvarchar(50) = '',
	@Apellido nvarchar(50) = '',
	@Email nvarchar(50) = '',
	@Clave nvarchar(50) = '',
	@Telefono nvarchar(30) = '',	
	@Tipo varchar(30) = ''
	as
		begin
			update Usuarios set Nombre = @Nombre, Apellido = @Apellido, Email = @Email, Clave = @Clave, Telefono = @Telefono, Tipo = @Tipo where Codigo_Usuarios = @Codigo_Usuarios;
		end

--SP Tabla Producto
create procedure ConsultarProducto
	as
		begin
		select * from Producto
		end

create procedure IngresarProducto
	@Nombre nvarchar(50) = '',
	@Precio int
	as
		begin
			insert into Producto (Nombre, Precio) values (@Nombre, @Precio)
		end

create procedure BorrarProducto
	@Codigo_Producto int
	as
		begin
			delete Producto where Codigo_Producto = @Codigo_Producto
		end

create procedure ActualizarProducto
	@Codigo_Producto int,
	@Nombre nvarchar(50) = '',
	@Precio int
	as
		begin
			update Producto set Nombre = @Nombre, Precio = @Precio where Codigo_Producto = @Codigo_Producto;
		end

--SP Tabla Factura
create procedure ConsultarFactura
	as
		begin
		select * from Factura
		end

create procedure IngresarFactura
	@Num_Factura int,
	@Fecha date,
	@Cod_Usuario int,
	@Total int,
	@IV_Total int
	as
		begin
			insert into Factura (Num_Factura, Fecha, Cod_Usuario, Total, IV_Total) values (@Num_Factura, getdate(), @Cod_Usuario, @Total, @IV_Total)
		end

create procedure BorrarFactura
	@Num_Factura int
	as
		begin
			delete Factura where Num_Factura = @Num_Factura
		end

create procedure ActualizarFactura
	@Num_Factura int,
	@Fecha date,
	@Cod_Usuario int,
	@Total int,
	@IV_Total int
	as
		begin
			update Factura set Num_Factura = @Num_Factura, Fecha = getdate(), Cod_Usuario = @Cod_Usuario, Total = @Total, IV_Total = @IV_Total where Num_Factura = @Num_Factura;
		end

--SP Tabla DetalleFactura
create procedure ConsultarDetalleFactura
	as
		begin
		select * from DetalleFactura
		end

create procedure IngresarDetalleFactura
	@N_Factura int,
	@Codigo_Producto int,
	@Cantidad int,
	@Precio_Unitario int,
	@IV int
	as
		begin
			insert into DetalleFactura (N_Factura, Codigo_Producto, Cantidad, Precio_Unitario, IV) values (@N_Factura, @Codigo_Producto, @Cantidad, @Precio_Unitario, @IV)
		end

create procedure BorrarDetalleFactura
	@Codigo_Factura int
	as
		begin
			delete DetalleFactura where Codigo_Factura = @Codigo_Factura
		end

create procedure ActualizarDetalleFactura
	@Codigo_Factura int,
	@N_Factura int,
	@Codigo_Producto int,
	@Cantidad int,
	@Precio_Unitario int,
	@IV int
	as
		begin
			update DetalleFactura set N_Factura = @N_Factura, Codigo_Producto = @Codigo_Producto, Cantidad = @Cantidad, Precio_Unitario = @Precio_Unitario, IV = @IV where Codigo_Factura = @Codigo_Factura;
		end

--SP Tabla Provincia
create procedure ConsultarProvincia
	as
		begin
		select * from Provincia
		end

create procedure IngresarProvincia
	@Codigo_Provincia int,
	@Nombre nvarchar(50) = ''
	as
		begin
			insert into Provincia (Codigo_Provincia, Nombre) values (@Codigo_Provincia, @Nombre)
		end

create procedure BorrarProvincia
	@Codigo_Provincia int
	as
		begin
			delete Provincia where Codigo_Provincia = @Codigo_Provincia
		end

create procedure ActualizarProvincia
	@Codigo_Provincia int,
	@Nombre nvarchar(50) = ''
	as
		begin
			update Provincia set Codigo_Provincia = @Codigo_Provincia, Nombre = @Nombre where Codigo_Provincia = @Codigo_Provincia;
		end

--SP Tabla Canton
create procedure ConsultarCanton
	as
		begin
		select * from Canton
		end

create procedure IngresarCanton
	@Codigo_Canton int,
	@Nombre nvarchar(50) = '',
	@Cod_Provincia int
	as
		begin
			insert into Canton (Codigo_Canton, Nombre, Cod_Provincia) values (@Codigo_Canton, @Nombre, @Cod_Provincia)
		end

create procedure BorrarCanton
	@Codigo_Canton int
	as
		begin
			delete Canton where Codigo_Canton = @Codigo_Canton
		end

create procedure ActualizarCanton
	@Codigo_Canton int,
	@Nombre nvarchar(50) = '',
	@Cod_Provincia int
	as
		begin
			update Canton set Codigo_Canton = @Codigo_Canton, Nombre = @Nombre, Cod_Provincia = @Cod_Provincia where Codigo_Canton = @Codigo_Canton;
		end

--SP Tabla Distrito
create procedure ConsultarDistrito
	as
		begin
		select * from Distrito
		end

create procedure IngresarDistrito
	@Codigo_Distrito int,
	@Nombre nvarchar(50) = '',
	@Cod_Canton int
	as
		begin
			insert into Distrito (Codigo_Distrito, Nombre, Cod_Canton) values (@Codigo_Distrito, @Nombre, @Cod_Canton)
		end

create procedure BorrarDistrito
	@Codigo_Distrito int
	as
		begin
			delete Distrito where Codigo_Distrito = @Codigo_Distrito
		end

create procedure ActualizarDistrito
	@Codigo_Distrito int,
	@Nombre nvarchar(50) = '',
	@Cod_Canton int
	as
		begin
			update Distrito set Codigo_Distrito = @Codigo_Distrito, Nombre = @Nombre, Cod_Canton = @Cod_Canton where Codigo_Distrito = @Codigo_Distrito;
		end

--SP Tabla Direcciones
create procedure ConsultarDirecciones
	as
		begin
		select * from Direcciones
		end

create procedure IngresarDirecciones
	@C_Usu int,
	@C_Prov int,
	@C_Cant int,
	@C_Dist int,
	@Comentarios nvarchar(50) = ''
	as
		begin
			insert into Direcciones (C_Usu, C_Prov, C_Cant, C_Dist, Comentarios) values (@C_Usu, @C_Prov, @C_Cant, @C_Dist, @Comentarios)
		end

create procedure BorrarDirecciones
	@C_Usu int
	as
		begin
			delete Direcciones where C_Usu = @C_Usu
		end

create procedure ActualizarDirecciones
	@Codigo_Direcciones int,
	@C_Usu int,
	@C_Prov int,
	@C_Cant int,
	@C_Dist int,
	@Comentarios nvarchar (50)
	as
		begin
			update Direcciones set C_Usu = @C_Usu, C_Prov = @C_Prov, C_Cant = @C_Cant, C_Dist = @C_Dist, Comentarios = @Comentarios where C_Usu = @C_Usu;
		end

--SP para Login
create procedure ConsultarLogin
	@Email nvarchar(50) = '',
	@Clave nvarchar(50) = ''	
	as
		begin
			select * from Usuarios where Email = @Email and Clave = @Clave
		end

--SP para Ver Datos de los Uusarios del sistema del GYM
create procedure VerDatosUsuariosGym
	as
		begin
			select U.Codigo_Usuarios, U.Nombre, U.Apellido, U.Email, D.C_Prov, D.C_Cant, D.C_Dist, D.Comentarios
			from Direcciones D
			inner join Usuarios U on D.C_Usu = U.Codigo_Usuarios
		end

--Insertamos datos default a algunas tablas
insert into Producto values ('Mensualidad', 30000), ('Proteina', 5000), ('Camisetas', 12500), ('Shorts', 9500), ('Guantes', 6500)
select * from Producto

insert into Provincia values (1, 'San Jos�'), (2, 'Alajuela'), (3, 'Heredia'), (4, 'Cartago')
select * from Provincia

insert into Canton values (1, 'San Jos�', 1), (2, 'Escaz�', 1), (3, 'Alajuela', 2), (4, 'Atenas', 2), (5, 'Heredia', 3), (6, 'Barva', 3), (7, 'Cartago', 4), (8, 'Para�so', 4)
select * from Canton

insert into Distrito values (1, 'La Uruca', 1), (2, 'San Antonio', 2), (3, 'Tambor', 3), (4, 'Escobal', 4), (5, 'Mercedes', 5), (6, 'Varablanca', 6), (7, 'Tierra Blanca', 7), (8, 'Orosi', 8)
select * from Distrito

--Para el correcto funcionamiento del sistema, ac� crearemos el primer usuario Admin para poder iniciar el uso de la p�gina web.
--Por favor ingrese sus datos como primer usuario, y por default dejar en "Admin" el "Tipo"
insert into Usuarios values ('@Nombre', '@Apellido', '@Correo', '@Clave', '@Tel�fono', 'Admin')

--Luego insertamos los datos relaciones a la direcci�n del primer usuario del sistema (luego todo podr� ser manejado desde lo interno del sistema).
--Por default tendr� el c�digo 1 de usuario, luego debe elegir Provincia, Canton, Distrito y Direcci�n exacta
--Provincia: 1 San Jos�, 2 Alajuela
--Canton: 1 San Jos�, 2 Alajuela, 3 Tib�s
--Distrito: 1 San Juan, 2 Barrio San Jos�, 3 Hatillo
insert into Direcciones values (1, 1, 1, 1, '-INGRESE DIRECCI�N EXACTA-')