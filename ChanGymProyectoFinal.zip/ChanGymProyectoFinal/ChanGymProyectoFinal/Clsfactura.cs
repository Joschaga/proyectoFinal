﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;

namespace ChanGymProyectoFinal
{
    public class Clsfactura
    {
        public static int Codigo_Factura { get; set; }
        public static int N_Factura { get; set; }
        public static int Codigo_Producto { get; set; }
        public static int Cantidad { get; set; }
        public static int Precio_Unitario { get; set; }
        public static int IV { get; set; }
        public static int Total { get; set; }

        public static int AgregarDetalleFactura(int cod_fact, int cod_prod, int cant, int precio)
        {
            int retorno = 0;

            SqlConnection Conn = new SqlConnection();

            try
            {
                using (Conn = DboConn.obtenerConexion())
                {
                    SqlCommand cmd = new SqlCommand("ConsultarDetalleFactura", Conn)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                    cmd.Parameters.Add(new SqlParameter("@Codigo_Factura", cod_fact));
                    cmd.Parameters.Add(new SqlParameter("@Codigo_Producto", cod_prod));
                    cmd.Parameters.Add(new SqlParameter("@Cantidad", cant));
                    cmd.Parameters.Add(new SqlParameter("@Precio", precio));

                    retorno = cmd.ExecuteNonQuery();
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
                retorno = -1;
            }
            finally
            {
                Conn.Close();
            }
            return retorno;
        }

        public static int AgregarMaestroFactura(string cod, string total)
        {
            int retorno = 0;

            SqlConnection Conn = new SqlConnection();

            try
            {
                using (Conn = DboConn.obtenerConexion())
                {
                    SqlCommand cmd = new SqlCommand("ConsultarFactura", Conn)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                    cmd.Parameters.Add(new SqlParameter("@Cod_Usuario", cod));
                    cmd.Parameters.Add(new SqlParameter("@Total", total));

                    retorno = cmd.ExecuteNonQuery();
                }
            }
            catch (System.Data.SqlClient.SqlException ex)
            {
                retorno = -1;
            }
            finally
            {
                Conn.Close();
            }
            return retorno;
        }
    }
}